
public class Direction {

}
